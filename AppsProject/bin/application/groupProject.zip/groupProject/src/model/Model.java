package model;

import java.io.IOException;

import application.BracketController;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

public class Model {

	public static void bWindow(FXMLLoader currStage, ActionEvent event) throws IOException {
		//set up view for bracket window screen
		AnchorPane bracket = currStage.load();
		Stage window = (Stage) ((Node)event.getSource()).getScene().getWindow();
		Scene display = new Scene(bracket,1080,1080);
		window.setScene(display);
		window.setResizable(false);
		
	}
	
	public static void cWindow(FXMLLoader currStage, ActionEvent event) throws IOException {
		//set up view for bracket window screen
		AnchorPane calendar = currStage.load();
		Stage window = (Stage) ((Node)event.getSource()).getScene().getWindow();
		Scene display = new Scene(calendar,1080,1080);
		window.setScene(display);
		window.setResizable(false);
		
	}
	
	public static void vWindow(FXMLLoader currStage, ActionEvent event) throws IOException {
		//set up view for bracket window screen
		AnchorPane venues = currStage.load();
		Stage window = (Stage) ((Node)event.getSource()).getScene().getWindow();
		Scene display = new Scene(venues,1080,1080);
		window.setScene(display);
		window.setResizable(false);
		
	}
	
	public static void home(ActionEvent event, AnchorPane homeStage) {
		Scene scene = new Scene(homeStage,1080,1080);
		Stage window = (Stage) ((Node)event.getSource()).getScene().getWindow();
		window.setScene(scene);
		window.show();
		window.setResizable(false);
		
	}

}
