package application;

import java.io.IOException;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.Button;
import javafx.scene.layout.AnchorPane;
import model.Model;

public class SportsController {

    @FXML
    private Button bTeamWindow;

    @FXML
    private AnchorPane background;

    @FXML
    private Button bBracket;

    @FXML
    private Button bVenue;

    @FXML
    void swapToBracket(ActionEvent event) throws IOException {
		FXMLLoader currStage = new FXMLLoader(getClass().getResource("Bracket.fxml"));
		Model.bWindow(currStage, event);

    }

    @FXML
    void swapToTeam(ActionEvent event) throws IOException {
		FXMLLoader currStage = new FXMLLoader(getClass().getResource("Bracket.fxml"));
		Model.cWindow(currStage, event);

    }

    @FXML
    void switchToVenues(ActionEvent event) throws IOException {
		FXMLLoader currStage = new FXMLLoader(getClass().getResource("Venues.fxml"));
		Model.vWindow(currStage, event);

    }

}
