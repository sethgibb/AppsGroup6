package application;

import java.io.IOException;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.Button;
import javafx.scene.layout.AnchorPane;
import model.Model;

public class BracketController {
	@FXML
	private Button bHome;
	
	public void homeB(ActionEvent event) throws IOException {
		//return to home screen
		AnchorPane homeStage = (AnchorPane)FXMLLoader.load(getClass().getResource("SportsSchedule.fxml"));
		Model.home(event, homeStage);
		
	}
}
